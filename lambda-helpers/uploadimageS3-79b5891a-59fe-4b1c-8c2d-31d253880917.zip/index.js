const AWS = require("aws-sdk");
AWS.config.update({ region: process.env.AWS_SESSION });
const s3 = new AWS.S3();

//Main Lambda entry point
exports.handler = async (event) => {
	

	
	const result = await getUploadURL(event.videoName);
	console.log("Result: ", result);
	return result;
}

const getUploadURL = async (videoName) => {

	
	var fileId;
	if(videoName)	
		fileId =  videoName;
	else
		fileId = parseInt(Math.random()*1000000000000)
		
	
	const signedUrlExpireSeconds = 10;
	
	const s3Params = {
	Bucket: process.env.UploadBucket,
	Key: `${fileId}.mp4`,
	ContentType: "video/mp4"
	}


	console.log("getUploadURL", s3Params)
	return new Promise((resolve, reject) => {
	//Get Signed URL
	resolve({"body": JSON.stringify({
			"uploadURL": s3.getSignedUrl("putObject", s3Params),
			"videoFilename": `${fileId}.mp4`
			
			})
		})

	})
}